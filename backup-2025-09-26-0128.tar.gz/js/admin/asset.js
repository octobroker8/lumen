
 

function assetsList(q = ''){
	$.ajax({
	   url: '/dashboard/asset/list',
	   type: 'post',
	   data: {'q': q},
	   error:function(){
	   },
	   success: function(data){
		  $('.table').html(data);
		    _switch();
	   }
    });	 
}



function assetsListBinary(q = ''){
	// console.log('Q: ', q);
	$.ajax({
	   url: '/dashboard/asset/list_binary',
	   type: 'post',
	   data: {'q': q},
	   error:function(){
	   },
	   success: function(data){
		  $('.table').html(data);
		    _switch();
	   }
    });	 
}


function setAssetStatus(el, id){
  setTimeout(function(){
	 var v = $(el).find('input').val();
	 $.ajax({
	   url: '/dashboard/asset/status',
	   type: 'post',
	   data: {'v':v, 'id':id},
	   error:function(){
	   },
	   success: function(data){
		 
	   }
     });
  },200);
}


