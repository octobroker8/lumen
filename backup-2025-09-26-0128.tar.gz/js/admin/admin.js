var user_type = 0;



function setUserType(el, v){
	 $('.users .submenu .item').removeClass('selected');
	 $(el).addClass('selected');
	 user_type = v;
	 usersList(1);
	 $('#q').val('');
}

function userSearch(v){
	 usersList(1, v);
}



function usersList(page, q = ''){
	$.ajax({
	   url: '/dashboard/users/list',
	   type: 'post',
	   data: {'page':page, 'user_type': user_type, 'q': q},
	   error:function(){
	   },
	   success: function(data){
		  $('#list').html(data);
	   }
    });	 
}


function usersListUpdateAmounts(){
	var user_list = new Array();
	$('#list .str').each(function(i, el) {
       var user_id =  $(el).attr('value');
       user_list.push();
    });
	$.ajax({
	   url: '/dashboard/users/amounts',
	   type: 'post',
       data: {'json': 1, 'user_list':user_list},
	   dataType: "json",	
	   error:function(){
		    setTimeout(function(){ usersListUpdateAmounts(); }, 2000);   
	   },
	   success: function(users){
	    $('#list .str').each(function(i, el) {
          var id =  $(el).attr('value');
		  var i = getUser(users, id);
	      $(el).find('.balance').html('$'+i['balance']);
		  $(el).find('.profit').html('$'+i['profit']);
          $(el).find('.lots').html(i['lots']);
       });
		   
		 setTimeout(function(){ usersListUpdateAmounts(); }, 2000);   
	   } 
    });	 
}


function getUser(users, id){
	for(var i = 0; i < users.length; i++){
		if(users[i]['id'] == id){
		   return users[i];
		}
	}
}

function  openWindow(url){
	 $('.window').hide();
	 $.ajax({
	   url: url,
	   type: 'get',
	   error:function(){
	   },
	   success: function(data){
		  $('.window').html(data);
		  $('.window').show();
	   }
     });
}


function  openConfig(url){
	$('.windowConfig').hide();
	$.ajax({
	  url: url,
	  type: 'get',
	  error:function(){
	  },
	  success: function(data){
		 $('.windowConfig').html(data);
		 $('.windowConfig').show();
	  }
	});
}


 
function  closeConfig(){
	$('.windowConfig').hide();
	$('.windowConfig').html('');
 }


function  closeWindow(){
   $('.window').hide();
   $('.window').html('');
}


function playSound(src) {
    var audio = new Audio(src);
    audio.play();
}


function sc() {
    // playSound("sounds/click.mp3");
}

 

function _switch(){
	$(".switch").each(function(){
		var st = $(this).find('input').val();
		if(st == 1){  
		  $(this).css('background-color', '#318ED2');
		  $(this).find('.c').css('margin-left', '24px');
		}
    });
    $(".switch").on( "click", function() {
		var st = $(this).find('input').val();
		if(st == 1){  
			$(this).find('input').val('0');
		    $(this).css('background-color', '#3E4664');
		    $(this).find('.c').css('margin-left', '4px');
		}else{
			$(this).find('input').val('1');
			$(this).css('background-color', '#318ED2');
		    $(this).find('.c').css('margin-left', '24px');
		}
      sc();
   });
}

function confirmDel(el){
    $('.del .confirm').hide(); 
	$(el).parent().find('.confirm').show();
}


var lots_status = 0;
function lotsStatus(el, v){
	 $('.lots .submenu .item').removeClass('selected');
	 $(el).addClass('selected');
	 lots_status = v;
	 lotsList();
}



var prev_lots = '';
function lotsList(){
	$.ajax({
	   url: '/dashboard/lots/list',
	   type: 'post',
	   data: {'q': $('#q').val(), 'status':lots_status},
	   error:function(){
	   },
	   success: function(data){
		  if(prev_lots != data){
			 prev_lots = data;
			 $('#list').html(data);
		  }
		  setTimeout(function(){ lotsList();  }, 1000);    
	   }
    });	 
}

var prev_referal = '';
function ReferalList(){
	$.ajax({
	   url: '/dashboard/partners/referals',
	   type: 'post',
	   data: {'q': $('#q').val()},
	   error:function(){
	   },
	   success: function(data){
		  if(prev_referal != data){
			 prev_referal = data;
			 $('#list').html(data);
		  }
		  setTimeout(function(){ ReferalList();  }, 2000);    
	   }
    });	 
}





function setPaysystemStatus(el, id){
  setTimeout(function(){
	 var v = $(el).find('input').val();
	 $.ajax({
	   url: '/dashboard/paysystem/status',
	   type: 'post',
	   data: {'v':v, 'id':id},
	   error:function(){
	   },
	   success: function(data){
		 
	   }
     });
  },200);
}




var stat_online = 1;
var stat_prev;

function statList(){
	$.ajax({
	   url: '/dashboard/stat/list',
	   type: 'post',
	   data: {'stat_online':stat_online},
	   error:function(){
	   },
	   success: function(data){
		  if(stat_prev != data){
			 stat_prev = data;
			 $('#list').html(data);
		  }
		  setTimeout(function(){ statList();  }, 2000);    
	   }
    });	 
}

function setPayoutType(el, status){
	$('.assets .submenu .item').removeClass('selected');
	$(el).addClass('selected');
	// user_type = v;
	payoutList(status);
	// $('#q').val('');
}


 
var payout_prev = '';
function payoutList(status){

	if(status == 5){
		//$(".tabela_solicitacoes").css('display','none');
		//$(".tabela_historico").css('display','block');

		$.ajax({
			url: '/dashboard/payout/history',
			type: 'post',
			error:function(){
			},
			success: function(data){
				if(payout_prev != data){
					payout_prev = data;
					$('#list-history').html(data);
				}
				// setTimeout(function(){ payoutList(status); }, 5000);    
			}
    	});	 
	}else{
		//$(".tabela_solicitacoes").css('display','block');
		//$(".tabela_historico").css('display','none');

		$.ajax({
			url: '/dashboard/payout/list',
			type: 'post',
			error:function(){
			},
			success: function(data){
				if(payout_prev != data){
					payout_prev = data;
					$('#list').html(data);
				}
				// setTimeout(function(){ payoutList(status); }, 5000);    
			}
    	});	 
	}

}



function payoutListSearch(page, val){
	// console.log(val);
	// console.log(payout_prev);

	$.ajax({
		url: '/dashboard/payout/list',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			if(payout_prev != data){
				payout_prev = data;
				$('#list').html(data);
			}   
		}
	});	 

}

function payoutHistorySearch(page, val){

	$.ajax({
		url: '/dashboard/payout/history',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			if(payout_prev != data){
				payout_prev = data;
				$('#list-history').html(data);
			}   
		}
	});	 

}

var payout_prev_afiliado = '';
function payoutListAfiliado(status){

	if(status == 5){
		//$(".tabela_solicitacoes").css('display','none');
		//$(".tabela_historico").css('display','block');

		$.ajax({
			url: '/dashboard/afiliados/retiradas_history',
			type: 'post',
			error:function(){
			},
			success: function(data){
				if(payout_prev_afiliado != data){
					payout_prev_afiliado = data;
					$('#list-history-afiliado').html(data);
				}
				// setTimeout(function(){ payoutListAfiliado(status); }, 5000);    
			}
    	});	 
	}else{
		//$(".tabela_solicitacoes").css('display','block');
		//$(".tabela_historico").css('display','none');

		$.ajax({
			url: '/dashboard/afiliados/retiradas_list',
			type: 'post',
			error:function(){
			},
			success: function(data){
				if(payout_prev_afiliado != data){
					payout_prev_afiliado = data;
					$('#list-afiliado').html(data);
				}
				// setTimeout(function(){ payoutListAfiliado(status); }, 5000);    
			}
    	});	 
	}

}

function payoutListAfiSearch(page, val){
	// console.log(val);
	// console.log(payout_prev);

	$.ajax({
		url: '/dashboard/afiliados/retiradas_list',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			if(payout_prev_afiliado != data){
				payout_prev_afiliado = data;
				$('#list-afiliado').html(data);
			}
		}
	});	 

}

function payoutHistoryAfiSearch(page, val){

	$.ajax({
		url: '/dashboard/afiliados/retiradas_history',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			if(payout_prev_afiliado != data){
				payout_prev_afiliado = data;
				$('#list-history-afiliado').html(data);
			}
		}
	});	 

}

function payoutAccept(id){
	sc();
	$.ajax({
	   url: '/dashboard/payout/accept',
	   type: 'post',
	   data: {'id':id},
	   error:function(){
		payoutList(3)
	   },
	   success: function(data){
		payoutList(3)
	   }
    });	 
}

function payoutCancel(id){
	sc();
	$.ajax({
	   url: '/dashboard/payout/cancel',
	   type: 'post',
	   data: {'id':id},
	   error:function(){
		payoutList(3)
	   },
	   success: function(data){   
		payoutList(3)
	   }
    });	 
}

$(document).ready(function() {
    _switch();

	
	$( "a" ).on( "click", function() {
      sc();
   });
	
	
   $('input').attr('autocomplete','off');
		
});

function getDadosUser(el, acao){
	$('.submenu_user .item').removeClass('selected');
	$(el).addClass('selected');

	$('.user_depositos').addClass('sumiu');
	$('.user_saques').addClass('sumiu');
	$('.user_operacoes').addClass('sumiu');
	$('.user_afiliados').addClass('sumiu');
	$('.'+acao).removeClass('sumiu');
	
	
	

	// user_type = v;
	//dadosUser(acao);
	// $('#q').val('');
}


function dadosUser(acao){
	console.log(acao);

	// if(status == 5){
	// 	$(".tabela_solicitacoes").css('display','none');
	// 	$(".tabela_historico").css('display','block');

	// 	$.ajax({
	// 		url: '/dashboard/payout/history',
	// 		type: 'post',
	// 		error:function(){
	// 		},
	// 		success: function(data){
	// 			if(payout_prev != data){
	// 				payout_prev = data;
	// 				$('#list').html(data);
	// 			}
	// 			// setTimeout(function(){ payoutList(status); }, 2000);    
	// 		}
    // 	});	 
	// }else{
	// 	$(".tabela_solicitacoes").css('display','block');
	// 	$(".tabela_historico").css('display','none');

	// 	$.ajax({
	// 		url: '/dashboard/payout/list',
	// 		type: 'post',
	// 		error:function(){
	// 		},
	// 		success: function(data){
	// 			if(payout_prev != data){
	// 				payout_prev = data;
	// 				$('#list').html(data);
	// 			}
	// 			// setTimeout(function(){ payoutList(status); }, 2000);    
	// 		}
    // 	});	 
	// }

}

function getConfiUser(el, acao){
	$('.submenu_user .item').removeClass('selected');
	$(el).addClass('selected');

	$('.user_conf_dados').addClass('sumiu');
	$('.user_conf_privilegios').addClass('sumiu');
	$('.user_conf_vips').addClass('sumiu');
	$('.user_conf_banca').addClass('sumiu');
	$('.user_conf_rev').addClass('sumiu');
	$('.user_conf_afi').addClass('sumiu');
	$('.'+acao).removeClass('sumiu');
	
}
