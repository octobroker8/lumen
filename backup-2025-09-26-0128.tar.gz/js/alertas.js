function alerta_sucesso(){

    // console.log('chegou...');

    $('.alert-success').fadeIn();

    setTimeout(function () { 
        $('.alert-success').fadeOut();
    }, 3000);
		 
}

function opWin(){

    $('#opWin').addClass('mostrarModal');

    setTimeout(function () { 
        $('#opWin').removeClass('mostrarModal');
    }, 5000);	
	 
}

function opLoss(){

    $('#opWin').removeClass('mostrarModal');

    setTimeout(function () { 
        $('#opLoss').removeClass('mostrarModal');
    }, 5000);	
	 
}

function fecharModalResultsWin(){
    $('#opWin').removeClass('mostrarModal');
}

function fecharModalResultsLoss(){
    $('#opLoss').removeClass('mostrarModal');
}