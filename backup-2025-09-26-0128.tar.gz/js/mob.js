// Interface functions for mobile version


var lang = 'en';
var sound_status = 1;


function openPage(url){
	  sc();
	  $(".slider_menu").hide();
	  $.ajax({
	   url: url,
	   type: 'get',
	   error:function(){
          
	   },
	   success: function(data){
		    $('#page').html(data);
		    $('#page').show();
	   }
       });	 
}

function closePage(){
	  $('#page').hide();
	  sc();
      $(".slider_menu").hide();
}


function openPage2(url){
	  sc();
	  $.ajax({
	   url: url,
	   type: 'get',
	   error:function(){
          
	   },
	   success: function(data){
		    $('#page2').html(data);
		    $('#page2').show();
	   }
       });	 
}

function closePage2(){
	  $('#page2').hide();
	  sc();
}



function setCurrency(id) {
    w1.setCurrency(id); 
	saveWindow(1, id);
    $('.currency_list').hide();
	sc();
}



function openCurrencylist() {
    if ($(".currency_list").css('display') != "none") {
		  $('.currency_list').hide();
	}else{
		  $('.currency_list').show();
	}
	
}

function getCurrencylist(forex, obj = '') {
	 
	 if(obj){
		$('.mitem').removeClass('selected');
        $(obj).addClass('selected');
     }

	 $.ajax({
	   url: '/mob/currency/'+forex,
	   type: 'get',
	   error:function(){
           
	   },
	   success: function(data){
		  $('#currency_list').html(data);
	   }
     });
}




 
var serverdata =  new Array();	
function _server(){
	  $.ajax({
	   url: '/traderoom/serverdata',
	   type: 'post',
       data: {'json': 1},
       dataType: "json",	
	   error:function(){
           setTimeout(function(){ _server(); }, 2500);
	   }.bind(this),
	   success: function(data){
		   serverdata = data;
		  countLots();
			binaryTime();
			binaryTimeList()
		   balance();
		   alerts();
		   logout();
		   profitOpenLots();
		   setTimeout(function(){ _server(); }, 500);   
	   }.bind(this)
       });	 
}

var rankings =  new Array();	
function _ranking() {
    $.ajax({
        url: '/traderoom/rankingdata',
        type: 'post',
        data: {'json': 1},
        dataType: "json",
        error:function() {
            setTimeout(function(){_ranking();}, 45000);
        }.bind(this),
        success: function(data){
            rankings = data;
            rankings_();
            setTimeout(function(){ _ranking(); }, 30000);   
        }.bind(this)

    });
}

function binaryTime() {
    
	let obj = $('#w1');
	let texto = obj.find('.selects_text');
	let input = obj.find('input[name="binarytime"]');
	let temp_restante = obj.find('.temp_restante');
	let selects_time = obj.find('.selects_time');
	let tempo = new Date(serverdata.relogios[input.val()]*1000);
	let segundos = serverdata.relogios[input.val()] - serverdata.time;
	texto.html(`${String(tempo.getHours()).padStart(2, "0")}:${String(tempo.getMinutes()).padStart(2, "0")}`);
	temp_restante.html(`${String(Math.floor(segundos / 60)).padStart(2, "0")}:${String(segundos % 60).padStart(2, "0")}`)
	selects_time.html(input.val()/60 + 'M');

}

function binaryTimeList(){
	$('.binarytimes_list > div').each(function(index){
			let input = $(this).attr('value');
			let tempo = new Date(serverdata.relogios[input]*1000);
			let segundos = serverdata.relogios[input] - serverdata.time;
			$(this).find('.tempo_binario').html(`${String(tempo.getHours()).padStart(2, "0")}:${String(tempo.getMinutes()).padStart(2, "0")}`);
			$(this).find('.tempo_restante').html(`${String(Math.floor(segundos / 60)).padStart(2, "0")}:${String(segundos % 60).padStart(2, "0")}`)
	});
}

function rankings_() {
    let periodo = $('select[name="periodoRanking"]').val();
    let operadores = (periodo === 'today') ? rankings.today : (periodo === 'three') ? rankings.three : rankings.seven;
    if(operadores){

        $("#ranking_container").html('');
        let i = 1;
        operadores.forEach(op => {
            let nome = (op.o) ? op.o : op.i+' '+op.f;
            let desde = new Date(op.time*1000).toLocaleDateString();
            let valores = (op.profit > 25000) ? '+ R$ 25.000,00' : 'R$ '+Number(op.profit).toLocaleString('pt-br', {minimumFractionDigits: 2})
            let foto = (op.photo) ? op.photo : 'img/account/photo.png';
            let html = '';
            html += '<div class="item_rank">';
                html += '<div class="item_rank_left">';
                    html += '<p class="item_rank_'+i+'" style="min-width: 15px; background: var(--color1); border-radius: 4px; height: 15px; display: flex; align-items: center; justify-content: center;">'+i+'</p>';
                    html += '<img class="item_rank_img" src="'+foto+'" />'
                    html += '<div><p>'+nome+'</p></div>';
                html += '</div>';
			html +=	'<p>'+valores+'</p>';
			html +=	'</div>';

            $("#ranking_container").append(html);
            i++;
        });
    }
}

function alerts(){
	var m = serverdata.alert;
	if(m){
	   var html2;
	   var html;
	   
	   if(m.profit > 0){
        html2 = '<div class="n2" style="color: #fff;"><b>R$ '+m.profit+'</b></div>';
		html = '<div class="alertmessage id-'+m.id+'" style="background: var(--verde);">';
		playSound("sounds/win.mp3");
	   }else{
	    html2 = '<div class="n2" style="color: #fff;"><b>R$ '+m.profit+'</b></div>';
		html = '<div class="alertmessage id-'+m.id+'" style="background: var(--vermelho);">';
		playSound("sounds/loss.mp3");
	   }
      

    //    html = '<div class="alertmessage id-'+m.id+'">';
       html += '<img   class="icon"   src="img/icon/'+m.currency_k+'.png" alt="">'; 
	   html += '<div class="profitinfo">';
	   html += '<div  class="n1">'+m.currency_name+'</div>';
	   html += '<div class="clear"></div>';
       html += html2;
	   html += ' <div class="clear"></div>';   
	   html += ' </div> <div class="clear"></div> </div>';
	   
	   $('.main').append(html);
	
		setTimeout(function () { 
	      $('.id-'+m.id).animate({
           left:'-1500px'
          }, 5000, function() { 
		      $('.id-'+m.id).remove(); 
		      
	      });
	   }, 6000);
		
		
	 }
}


// Count and Update lots list
var  open_lots_prev = 0;
var  close_lots_prev = 0;
function countLots(){
	var count_open_lots = serverdata.count_lots_open;
    var count_close_lots = serverdata.count_lots_close;
	if(open_lots_prev != count_open_lots){
	   loadOpenLots();
	   open_lots_prev = count_open_lots;
	   $('#count_open_lots').html(count_open_lots);
	}
	if(close_lots_prev != count_close_lots){
	   loadCloseLots();
	   close_lots_prev = count_close_lots;
	   $('#count_close_lots').html(count_close_lots);
	}
}



function lotsMenu(el, v){
	sc();
	if(el) $('.lots_menu .item').removeClass('selected');
	$('#addlot').hide();
	$('#lots_open').hide();
    $('#lots_close').hide();
	
	if(v == 0){
		if(el) $(el).addClass('selected');
		$('#addlot').show();
	}
	if(v == 1){
		if(el) $(el).addClass('selected');
	    $('#lots_open').show();
	}
    if(v == 2){
	    if(el) $(el).addClass('selected');
	    $('#lots_close').show();
	}	
	
}




function loadOpenLots(){
	  $.ajax({
	   url: '/mob/lots/open',
	   type: 'get',
	   error:function(){  
	   },
	   success: function(data){
		    $('#lots_open').html(data);
	   }
       });
}
 


function loadCloseLots(){
	  $.ajax({
	   url: '/mob/lots/close',
	   type: 'get',
	   error:function(){
          
	   },
	   success: function(data){
		    $('#lots_close').html(data);
	   }
       });	 
}



function logout(){
      if(serverdata.logout == 1) redir('/login');
}




function balance(){
	var b = $('#balance_plugin').html();
	if(serverdata.demo == 1){
		numAnimate(b, serverdata.balance_demo); 
	}else{
	  numAnimate(b, serverdata.balance); 
	}	 
	$('#balance_real').html(Number(serverdata.balance).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
	$('#balance_demo').html(Number(serverdata.balance_demo).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));	
}



	   
function  numAnimate(b1, b2){
  if(this.b2_prev != b2){
	  this.b2_prev = b2; 
   $('#balance_plugin').prop('number', b1).animateNumber({
		  number: b2,
		  numberStep: function(now, tween) {
				  var separator = ".";	
				  var v = now.toFixed(2);
				  $(tween.elem).text(v);
				  var parts = v.toString().split(",");
				  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, separator);
				  v = parts.join(",");
				  
				  $('#balance').text(now.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
		  }
	  },0);
   }
} 


	
function  secondsToHms(d) {
       d = Number(d);
       var h = Math.floor(d / 3600);
       var m = Math.floor(d % 3600 / 60);
       var s = Math.floor(d % 3600 % 60);
	   if(h < 10) h = '0'+h;
       if(m < 10) m = '0'+m;
	   if(s < 10) s = '0'+s; 
       return h  +":"+ m +":"+ s ;
}
	

	

function timeEndCounterStart(){
	var lots = $("#lots_open").find('.table_str');
    for(var i=0;i<lots.length;i++){
		timeEndCounter(lots[i]);
    }
}
setInterval('timeEndCounterStart()',10);


function timeEndCounter(lot_el){
	var el = $(lot_el).find('.timer'); 
	var time_end = el.attr('end'); 
	var time_start = el.attr('start'); 
	var now = timeNow();
	if(time_end >= 0) {   
	 var max = time_end-time_start;		   
	 var sec = time_end-now;
	 if(now > time_end)   sec = sec*1+1; 
	 if(sec > max) sec = max;   
	 if(sec >= 0){
		 var d = secondsToHms(sec);
		 el.text(d);
		 
	 }
	}
}




function  profitOpenLots(){
	  var lots =  serverdata.lots_open;
	  $('.lots_open_profit').hide(); 
	  var profit_all = 0;	 
	  for (var i = 0; i < lots.length; i++) { 
		  var id  =  lots[i]['id'];
		  var profit = lots[i]['profit'];
		  var el = $('#lot_'+id).find('.profit');
		  
		
		  if(profit)el.html(amountFormat(profit.toString()));
       
		  
		  profit_all += 1 * profit;
	      if(profit <= 0){
			 el.addClass('profit_down');
			 el.removeClass('profit_up'); 
		  }else{
			 el.addClass('profit_up');
			 el.removeClass('profit_down');  
		  }
		  
		  
		 $('.lots_open_profit').html(amountFormat(profit_all.toFixed(2)));
		 $('.lots_open_profit').show();  
	  
	  }
}
		 		

function  amountFormat(v){
		 var r  = '';
		 if(v < 0){
			var s =  v.split('-');
			r = '- R$'+s[1]; 
		 }
		 if(v > 0){
			r = '+ R$'+v; 	 
		 }
		 if(v == 0){
			r = 'R$'+v; 	 
		 }
	return r; 
}
	
	

	
function   timeNow(){
	  return Math.floor(Date.now()/1000);
}
	



function _menu() {
    sc();
    if ($(".slider_menu").css('display') == "none") {
        $(".slider_menu").show();
        //$(".bgwindow").show();
    } else {
        $(".slider_menu").hide();
        $(".bgwindow").hide();
    }
}



function chartBodyClick(){
	$('.popup').hide(); 
	$(".slider_menu").hide();
	$(".formlist").hide();
    $('body').find('.iconbar_window').hide();
}
 

function addDemo() {
    sc();
    $.ajax({
        url: '/traderoom/balance/add_demo',
        type: 'get',
        success: function(response) {}
    });
}


var  window_id = 0;

function addTab(){
	window_id = 0;
    openblock('add_tab', '60px', '50%');
}
 




  

 
function setWindowType(type) {
    //sc();
		  $('#w1').css('z-index','2'); 
	if(type == 0){
		
 
	 
	  
		$('#w1').animate({"width":"100%"}, 400);
	   $('#w2').css('left','0');	
	  // $('#w1').css('width','100%');
	   $('#w2').css('width','100%');
		 
		
	}
	
	if(type == 1){
		
 
		
	 
	   $('#w1').css('left','0');
	   $('#w2').css('left','50%');
       $('#w1').animate({"width":"50%"}, 400);
	  // $('#w1').css('width','50%');
	   $('#w2').css('width','50%'); 
	
	}
	
	
    $.ajax({
        url: '/traderoom/save/window/' + type,
        type: 'get',
        success: function(response) {
           // location.reload();
        }
    });
	
	closeblock();
}







function saveTab(currency_id) {
    $.ajax({
        url: '/traderoom/tabs/add/' + currency_id,
        type: 'get',
        success: function(response) {
            tabs_list();
        }
    });
}

var lock_opentab = 0;

function delTab(currency_id) {
    sc();
    lock_opentab = 1;
    $.ajax({
        url: '/traderoom/tabs/del/' + currency_id,
        type: 'get',
        error: function() {
            lock_opentab = 0;
        },
        success: function(response) {
            tabs_list();
            lock_opentab = 0;
        }
    });
}


function openTab(currency_id) {
    if (lock_opentab == 1) return false;
    w1.setCurrency(currency_id);
    saveWindow(1, currency_id);
    sc();
}



function map(number, inMin, inMax, outMin, outMax) {
    return (number - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}


function tabs_width() {
    $('.add_tab').show();
    var all = $('.tabs .tab').length;
    if (all >= 10) $('.add_tab').hide();
    var s = $('.head_left').width();
    var r = $('.head_right').width();
    
	var w = $(window).width();
    
	$('.tabs .tab').eq(0).css('margin-left', '10px');

    if (w < 1200) return false;

    var t = w - (s + r) - 10;
    $('.tabs').css('width', t + 'px');

    // range map  1200px 1900px  =>  -80px  -5px
    var v = map(w, 1200, 2000, -80, -5);
    $('.tabs .tab').css('margin-left', v + 'px');
    $('.tabs .tab').eq(0).css('margin-left', '10px');
}




var months = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');




function playSound(src) {
    if (sound_status == 0) return false;
    var audio = new Audio(src);
    audio.play();
}


function sc() {
    // playSound("sounds/click.mp3");
}



function openblock(name, top, left) {
    sc();
    $("#" + name).css('top', top);
    $("#" + name).css('left', left);

    if (left == "50%") {
        var w = $("#" + name).width();
        w = w / 2;
        $("#" + name).css('margin-left', "-" + w + "px");
    } else {
        $("#" + name).css('margin-left', 0);
    }
    if ($("#" + name).css('display') == "none") {
        $("#" + name).show();
        //$(".bgwindow").show();
    } else {
        $("#" + name).hide();
        //$(".bgwindow").hide();
    }
}



function closeblock() {
    sc();
    $(".bgwindow").hide();
    $(".popup").hide();
}



function addFav(id) {
    sc();
    $.ajax({
        url: '/traderoom/currency/fav_add/' + id,
        type: 'get',
        success: function(response) {

            if (response == 'del') {
                $('#fav' + id).removeClass('active');
            }
            if (response == 'add') {
                $('#fav' + id).addClass('active');
            }
        }
    });
}
 


function saveWindow(num, currency_id) {
    $.ajax({
        url: '/traderoom/save/w' + num + '/' + currency_id,
        type: 'get',
        success: function(response) {}
    });
}




function redir(url) {
    document.location.href = url;
}


function selects() {
    $('.select2 select').bind('change', function() {
        var val = $(this).children(':selected').text();
        $(this).parent().find('.value').html(val);
    });
    var selected = $('.select2 option:selected');
    for (var j = 0; j < selected.length; j++) {
        if (selected[j]) {
            var val = $(selected[j]).text();
            $(selected[j]).parent().parent().find('.value').html(val);
        }
    }
}




 
function sound() {
	sc();
    if (sound_status == 1) {
        $('.sound').addClass('off');
        sound_status = 0;
    } else {
        $('.sound').removeClass('off');
        sound_status = 1;
    }
	
    savesound(sound_status);
}


function savesound(status) {
    $.ajax({
        url: '/traderoom/save/sound/' + status,
        type: 'get',
        success: function(response) {}
    });
}




function setCurrencyW2(id){
    var classname = "w2";
	if(window[classname] != undefined){
		 window[classname].setCurrency(id); 
		 saveWindow(2, id);
		 setWindowType(1);
	}
}

 



function isMobile() {
    if ($(window).width() < 800) return true;
    return false;
}



function windowH() {
    if (window.innerHeight) {
        return window.innerHeight;
    } else {
        return document.body.clientHeight;
    }
}




function select_click(obj) {
    sc();
    if ($(obj).parent().find('.selects_list').css('display') == "block") {
        $(obj).parent().find('.selects_list').hide();
    } else {
        $(obj).parent().find('.selects_list').show();
    }
}







function menuItemSize() {
     var w = $('.menu .slider_menu').width();
	 var b =   w / 3; // 3 blocks
	 b = b - 1 -(w/100*2); // -margin 1%
	 b = b.toFixed();	
	 $('.menu .slider_menu .item').css('width', b+'px');
	 $('.menu .slider_menu .item').css('height', b+'px');
	 $('.menu .slider_menu .item').css('margin', '1%');
}


function openChat(){
  sc();
  $(".slider_menu").hide();
  if($('.chat').css('display') == 'none'){
	  $('.chat').show();
  }else{
	  $('.chat').hide(); 
  }
}



function datapost(element){
	var data = '';
	var form = $(element).find('select');
    for(var i=0;i<form.length;i++){
		data  += form[i]['name'] +'='+form[i]['value']+ '&';
    }
	var form = $(element).find('input');
    for(var i=0;i<form.length;i++){
		 if($(form[i]).attr('type') == 'checkbox'){
		   if($(form[i]).prop('checked')){
              data  += form[i]['name'] +'='+form[i]['value']+ '&';
		   }else{
              data  += form[i]['name'] +'=&'; 
		   }
		 }else{
		   data  += form[i]['name'] +'='+form[i]['value']+ '&';
		 }
    }
  return data;
}

function _switch(){
	$(".switch").each(function(){
		var st = $(this).find('input').val();
		if(st == 1){  
		  $(this).css('background-color', '#318ED2');
		  $(this).find('.c').css('margin-left', '24px');
		}
    });
    $(".switch").on( "click", function() {
		var st = $(this).find('input').val();
		if(st == 1){  
			$(this).find('input').val('0');
		    $(this).css('background-color', '#3E4664');
		    $(this).find('.c').css('margin-left', '4px');
		}else{
			$(this).find('input').val('1');
			$(this).css('background-color', '#318ED2');
		    $(this).find('.c').css('margin-left', '24px');
		}
      sc();
   });
}

function mess(text){
  $('.mess').html(text);
  $('.mess').css('display', 'table');	
  $('.mess').removeClass('ok');
}

function mess2(text){
  $('.mess2').html(text);
  $('.mess2').css('display', 'table');	
  $('.mess2').removeClass('ok');
}

function messOk(text){
  $('.mess').html(text);
  $('.mess').css('display', 'table');		
  $('.mess').addClass('ok');
}

function mess2Ok(text){
  $('.mess2').html(text);
  $('.mess2').css('display', 'table');		
  $('.mess2').addClass('ok');
}


function formlist(){	
   $(".form2 .input_value").on( "click", function() {
	  var b =  $(this).parent().parent().find('.formlist');
	  if(b.css('display') != "none"){
		   b.hide();
      }else{
           b.show();
	  }
      sc();
   });
}

function openLeverageList(obj){	
	  var b =  $(obj).parent().parent().find('.formlist');
	  if(b.css('display') != "none"){
		   b.hide();
      }else{
           b.show();
	  }
      sc();
}




function formlistItemClick(){	
   $(".formlist .item").on( "click", function() {
	 var obj = $(this).parent().parent();

	 var v =  $(this).attr('value'); 
	 var t =  $(this).text();   
	   
	 obj.find('.input_value').text('00:00');
	 obj.find('input').val(v); 
	   
	 w1.binaryProfitLot(); 
	 w1.timepos = $(this).index();
	
	  $(".formlist").hide();  
     sc();
   });
}

$(window).resize(function() {
	if(!isMobile()) redir('/traderoom');
});


$(document).ready(function() {
	if(!isMobile()) redir('/traderoom');
	
	
	formlist();
	formlistItemClick();
	
	_switch();
	
	menuItemSize();
    $(window).on( "resize", function() {
       menuItemSize();
    });
	
     _server();
	 _ranking();
	getCurrencylist(7);
 
    $('.bodyclick').click(function(event) {
        event.stopPropagation();
    });
    $('body').click(function() {
        $(".bodyclick_hide").hide();
        $(".selects_list").hide();
    });


    $('.selects_label').click(function(event) {
        event.stopPropagation();
    });


});


abrirFecharLots('abrir');


function abrirFecharLots(acao){
	console.log(acao);

	if(acao == 'abrir'){

		$(".iconAbrir").hide();
        $(".iconFechar").show();


		$(".rodape").css('background','var(--bg)');		
		$(".menu_barra").css('transform','translateY(0px)');
		$(".chart").css('height','calc(100% - 245px)');

	}else{

		$(".iconAbrir").show();
        $(".iconFechar").hide();
		
		$(".rodape").css('background','none');	
		$(".menu_barra").css('transform','translateY(139px)');
		$(".chart").css('height','calc(100% - 105px)');
	}
}

var copyBusca_prev = '';
function copySearchUser(page, val){
	console.log(val);
	// console.log(payout_prev);

	$.ajax({
		url: '/traderoom/copy/filtro',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			// if(copyBusca_prev != data){
            //     copyBusca_prev = data;
                $('#listCopyUsers').html(data);
            // }
		}
	});	 

}