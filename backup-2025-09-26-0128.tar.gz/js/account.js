var lang = 'en';
var sound_status = 1;
// var isSocketOpen = false;
// var intentionalClosure = false;
// var tradeData;
// var Socket

function openPage(url){
	  sc();
	  $(".slider_menu").hide();
	  $.ajax({
	   url: url,
	   type: 'get',
	   error:function(){
          
	   },
	   success: function(data){
		    $('#page').html(data);
            $('#page').fadeIn();
		    // $('#page').show();
	   }
       });	 
}

function closePage(){
    $('#page').fadeOut();
    $('#page').hide();
    sc();
    $('.slider_menue').fadeOut();
    // $(".slider_menu").hide();
}


// var serverdata =  new Array();	

// function createSocket(){
//         intentionalClosure = false;
// 		if(isSocketOpen) {
// 			console.log(`WebSocket connection is already open`)
// 			return
// 		}
	
// 		const Socket = new WebSocket(
// 			"wss://demo.obxbroker.io/serverdata"
// 		  );
//         Sockets = Socket

// 		Socket.onopen = () => {
// 			isSocketOpen = true	
//             Socket.send(JSON.stringify({
//                 method: 'ServerData',
//               }))
// 		}
	
// 		Socket.onmessage = (event) => {
// 			tradeData = event.data
// 			if (!tradeData) {
// 				return;
// 			  }
// 			const data = JSON.parse(tradeData);
// 			if(data.ServerData) {
// 				serverdata = data.ServerData;
//                 binaryTime();
//                 binaryTimeList()
//                 countLots();
//                 balance();
//                 alerts();
//                 logout();
//                 profitOpenLots();
//                 profitOpenLotsJanela();
// 			}
// 		}
// 		Socket.onclose = () => {
// 			isSocketOpen = false
// 		if (!intentionalClosure) {
// 			console.log(
// 			`WebSocket connection closed. Reconnecting...`,
// 			)
// 			setTimeout(() => {
// 				createSocket()
// 			}, 2000)
// 		}
// 		}
//     }

 
function _server(){

}

var rankings =  new Array();	
function _ranking() {
    $.ajax({
        url: '/traderoom/rankingdata',
        type: 'post',
        data: {'json': 1},
        dataType: "json",
        error:function() {
            setTimeout(function(){_ranking();}, 45000);
        }.bind(this),
        success: function(data){
            rankings = data;
            rankings_();
            setTimeout(function(){ _ranking(); }, 30000);   
        }.bind(this)

    });
}


function binaryTime() {
    
    let obj = $('#w1');
    let texto = obj.find('.selects_text');
    let input = obj.find('input[name="binarytime"]');
    let temp_restante = obj.find('.temp_restante');
    let selects_time = obj.find('.selects_time');
    let tempo = new Date(serverdata.relogios[input.val()]*1000);
    let segundos = (serverdata.relogios[input.val()] - serverdata.time);
    texto.html(`${String(tempo.getHours()).padStart(2, "0")}:${String(tempo.getMinutes()).padStart(2, "0")}`);
    temp_restante.html(`${String(Math.floor(segundos / 60)).padStart(2, "0")}:${String(segundos % 60).padStart(2, "0")}`)
    selects_time.html(input.val()/60 + 'M');

}

function binaryTimeList(){
    $('.binarytimes_list > div').each(function(index){
        let input = $(this).attr('value');
        let tempo = new Date(serverdata.relogios[input]*1000);
        let segundos = serverdata.relogios[input] - serverdata.time;
        $(this).find('.tempo_binario').html(`${String(tempo.getHours()).padStart(2, "0")}:${String(tempo.getMinutes()).padStart(2, "0")}`);
        $(this).find('.tempo_restante').html(`${String(Math.floor(segundos / 60)).padStart(2, "0")}:${String(segundos % 60).padStart(2, "0")}`)
    });
}

function rankings_() {
    let periodo = $('select[name="periodoRanking"]').val();
    let operadores = (periodo === 'today') ? rankings.today : (periodo === 'three') ? rankings.three : rankings.seven;
    if(operadores){

        $("#ranking_container").html('');
        let i = 1;
        operadores.forEach(op => {
            let nome = (op.o) ? op.o : op.i+' '+op.f;
            let desde = new Date(op.time*1000).toLocaleDateString();
            let valores = (op.profit > 25000) ? '+ R$ 25.000,00' : 'R$ '+Number(op.profit).toLocaleString('pt-br', {minimumFractionDigits: 2})
            let foto = (op.photo) ? op.photo : 'img/account/photo.png';
            let html = '';
            html += '<div class="item_rank">';
                html += '<div class="item_rank_left">';
                    html += '<p class="item_rank_'+i+'" style="min-width: 15px; background: var(--color1); border-radius: 4px; height: 15px; display: flex; align-items: center; justify-content: center;">'+i+'</p>';
                    html += '<img class="item_rank_img" src="'+foto+'" />'
                    html += '<div><p>'+nome+'</p></div>';
                html += '</div>';
			html +=	'<p>'+valores+'</p>';
			html +=	'</div>';

            $("#ranking_container").append(html);
            i++;
        });
    }
}



function operacoes() {

    var lots = serverdata.lots_open;
    if(lots){
        $("#op_container").html('');
        lots.forEach(op => {
            let html = '';
            html += '<div id="lot_'+op.id+'" class="operacao" style="display: flex;flex-direction: row;justify-content: space-between;border-top: 1px solid var(--color1);padding: 7px 0; align-items: center;">';
                html += '<div class="clock_container"><div start="'+op.time_start+'" end="'+op.time_end+'" class="timer"><div class="donat outer-circle"><p class="clock-time clock-timer"><p></div></div></div>';
                html += '<div><div class="item" style="display: flex;align-items: center;gap: 5px;"><div class="currency_ico"><img width="18px" src="img/icon/'+op.currency_k+'.png" /></div><div class="currency" style="font-size: 14px"><b>'+op.currency+'</b></div></div><p style="font-size: 12px">Crypto</p></div>';
                html += '<div style="font-size: 12px"><p style="color: var(--verdeSaldo);"><b class="profit"> R$ '+op.profit+'</b></p><p style="display: flex;align-items: center;gap: 5px;font-size: 10px;">R$ '+op.lot+' <iconify-icon icon="bxs:'+op.trend+'-arrow" style="font-size: 10px;"></iconify-icon></p></div>'
            html += '</div>';

            $("#op_container").append(html);
        });

    }

} 

function historico(){
    var lots = serverdata.lots_close;

    if(lots){
        $("#op_container_close").html('');

        lots.forEach(op => {


            let cor = 'vermelho';
            if(op.profit <= 0) {
                cor = 'vermelho'
            }else{
                cor = 'verdeSaldo'
            }
            let cat = {
                7: 'Opções',	
                8: 'Crypto',	
                9: 'Stock'
            }
            let time = new Date(op.time_start*1000);
            let categoria = cat[op.currency_cat];
            let ano = time.getFullYear();
            let dia = time.getDate();
            let hora = time.getHours();
            let minutos = time.getMinutes();
            dia = (dia < 10) ? '0'+dia : dia;
            hora = (hora < 10) ? '0'+hora : hora;
            minutos = (minutos < 10) ? '0'+minutos : minutos;
            let html = '';
            html += '<div id="lot_'+op.id+'" class="operacao" style="display: flex;flex-direction: row;justify-content: space-between;border-top: 1px solid var(--color1);padding: 7px 0; align-items: center;">';
                html += '<div style="font-size: 12px; width: 30%; text-align: left;"><p><b>'+hora+':'+minutos+'</b></p><p style="font-size: 10px;">'+dia+' '+months_[time.getMonth()]+'</p></div>';
                html += '<div style="width: 35%; text-align: left;"><div class="item"  style="display: flex;align-items: center;gap: 5px;"><div class="currency_ico"><img width="18px" src="img/icon/'+op.currency_k+'.png" /></div><div class="currency" style="font-size: 14px"><b>'+op.currency+'</b></div></div><p style="font-size: 12px">'+categoria+'</p></div>';
                html += '<div style="font-size: 12px; text-align: right; width: 35%;"><p style="color: var(--'+cor+');"><b class="profit"> '+amountFormat(op.profit)+'</b></p><p style="display: flex;align-items: center;gap: 5px;font-size: 10px; flex-direction: row-reverse;">R$ '+op.lot+' <iconify-icon icon="bxs:'+op.trend+'-arrow" style="font-size: 9px;"></iconify-icon></p></div>'
            html += '</div>';

            $("#op_container_close").append(html);


        })
    }

}


function alerts(){
	var m = serverdata.alert;
	if(m){
        var html2;
        var html;
        
        if(m.profit > 0){
         html2 = '<div class="n2" style="color: #fff;"><b>R$ '+m.profit+'</b></div>';
         html = '<div class="alertmessage id-'+m.id+'" style="background: var(--verde);">';
         playSound("sounds/win.mp3");
        }else{
         html2 = '<div class="n2" style="color: #fff;"><b>R$ '+m.profit+'</b></div>';
         html = '<div class="alertmessage id-'+m.id+'" style="background: var(--vermelho);">';
         playSound("sounds/loss.mp3");
        }
    //    html = '<div class="alertmessage id-'+m.id+'">';
       html += '<img   class="icon"   src="img/icon/'+m.currency_k+'.png" alt="">'; 
	   html += '<div class="profitinfo">';
	   html += '<div  class="n1">'+m.currency_name+'</div>';
	   html += '<div class="clear"></div>';
       html += html2;
	   html += ' <div class="clear"></div>';   
	   html += ' </div> <div class="clear"></div> </div>';
	   $('.main').append(html);
	
		setTimeout(function () { 
	      $('.id-'+m.id).animate({
           left:'-1500px'
          }, 5000, function() { 
		      $('.id-'+m.id).remove(); 
		      
	      });
	   }, 6000);
		
		
	 }
}

 


// Count and Update lots list
var  open_lots_prev = 0;
var  close_lots_prev = 0;
function countLots(){
	var count_open_lots = serverdata.count_lots_open;
    var count_close_lots = serverdata.count_lots_close;
	if(count_open_lots > 0) {
        $('.count_open_lots_menu').removeClass('apagar')
    }else{
        $('.count_open_lots_menu').addClass('apagar')        
    }
	if(open_lots_prev != count_open_lots){
	   loadOpenLots();
	   open_lots_prev = count_open_lots;
       operacoes();
	   $('.count_open_lots_menu').html(count_open_lots);
       $('#count_open_lots').html(count_open_lots);
    }
	if(close_lots_prev != count_close_lots){
	   loadCloseLots();
       historico()
	   close_lots_prev = count_close_lots;
	   $('#count_close_lots').html(count_close_lots);
	}
}


 


function loadLots(classe, obj){

    if(classe){
		$('.top_name').removeClass('selected');
        $(obj).addClass('selected');
    }
    
    if(classe == "lots_abertos"){
        $('.lots_abertos').removeClass('apagar');
        $('.lots_fechados').addClass('apagar');
    } else {
        $('.lots_fechados').removeClass('apagar');
        $('.lots_abertos').addClass('apagar');
    }
}



function loadOpenLots(){
	  $.ajax({
	   url: '/traderoom/lots/open',
	   type: 'get',
	   error:function(){
           
	   },
	   success: function(data){
		    $('#lots_open').html(data);
		 
	   }
       });
}


 

function loadCloseLots(){
	  $.ajax({
	   url: '/traderoom/lots/close',
	   type: 'get',
	   error:function(){
          
	   },
	   success: function(data){
		    $('#lots_close').html(data);
	   }
       });	 
}



function logout(){
      if(serverdata.logout == 1) redir('/login');
}




function balance(){
	  var b = $('#balance_plugin').html();
	  if(serverdata.demo == 1){
	  	numAnimate(b, serverdata.balance_demo); 
	  }else{
		numAnimate(b, serverdata.balance); 
	  }	 
	  $('#balance_real').html(Number(serverdata.balance).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
	  $('#balance_demo').html(Number(serverdata.balance_demo).toLocaleString('pt-BR', { minimumFractionDigits: 2 }));	
	  $('#balance_invest').html(serverdata.balance_invest);
	  $('#partner_balance').html(serverdata.partner_balance);
}

 

	 	
function  numAnimate(b1, b2){
    if(this.b2_prev != b2){
      this.b2_prev = b2; 
	   $('#balance_plugin').prop('number', b1).animateNumber({
        number: b2,
        numberStep: function(now, tween) {
            var separator = ".";	
            var v = now.toFixed(2);
            $(tween.elem).text(v);
            var parts = v.toString().split(",");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, separator);
            v = parts.join(",");
            
            $('#balance').text(now.toLocaleString('pt-BR', { minimumFractionDigits: 2 }));
        }
      },0);
     }
} 

function timeEndCounterStartJanela(){
    var op = $("#op_container").find('.operacao');
    for(var i=0;i<op.length;i++){
		timeEndCounterJanela(op[i]);

    }
}

function timeEndCounterStart(){
	var lots = $("#lots_open").find('.table_str');
    for(var i=0;i<lots.length;i++){
		timeEndCounter(lots[i]);
    }
}


setInterval('timeEndCounterStart()',10);

setInterval('timeEndCounterStartJanela()',10);

function timeEndCounter(lot_el){
    var el = $(lot_el).find('.timer'); 
    var time_end = el.attr('end'); 
    var time_start = el.attr('start'); 
    var now = serverdata.time;
    if(time_end >= 0) {   
     var max = time_end-time_start;		   
     var sec = time_end-now;
     if(now > time_end)   sec = sec*1+1; 
     if(sec > max) sec = max;   
     if(sec >= 0){
       var d = secondsToHms(sec);
       el.text(d);
       
     }
    }
}

function timeEndCounterJanela(lot_el){
    var el = $(lot_el).find('.timer'); 
    var time_end = el.attr('end'); 
    var time_start = el.attr('start');
    var clock = el.find('.clock-timer');
    var circle = el.find('.outer-circle');
    var now = timeNow();
    if(time_end >= 0) {   
     var max = time_end-time_start;		   
     var sec = time_end-now;
     if(now > time_end)   sec = sec*1+1; 
     if(sec > max) sec = max;   
     if(sec >= 0){
       var d = secondsToHms(sec);
       clock.attr('clock',d);
       var porcentagem = Math.round((100 - (sec / max) * 100)) + '%';
       circle.css('background', 'linear-gradient(var(--bg), var(--bg)) content-box no-repeat, conic-gradient(var(--form-border) '+porcentagem+', 0, var(--color1) 100% ) border-box')
     }
    }
}

function  secondsToHms(d) {
       d = Number(d);
       var h = Math.floor(d / 3600);
       var m = Math.floor(d % 3600 / 60);
       var s = Math.floor(d % 3600 % 60);
       if(m < 10) m = '0'+m;
	   if(s < 10) s = '0'+s; 
       return m +":"+ s ;
}
	

	
function timeEndCounters(id){
	   var timer = $('#lot_'+id).find('.timer'); 
	   var time_end = timer.attr('val'); 
	   var now = timeNow();
	   if(time_end >= 0) {
	    var sec = time_end-now;
	    if(sec >= 0 ){
		  var d = secondsToHms(sec);
		  timer.text(d);
	    }
       }
}
	
function profitOpenLotsJanela() {
    var lots =  serverdata.lots_open;
    for(var i = 0; i < lots.length; i++) {
        var id  =  lots[i]['id'];
        var profit = lots[i]['profit'];
        var e = $('#op_container');
        var el = e.find('#lot_'+id).find('.profit');

        el.html('<b>'+amountFormat(profit)+'</b>');

        if(profit <= 0){
            el.css('color', 'var(--vermelho)');
        }else{

            el.css('color', 'var(--verde)');
        }


    }

}

function  profitOpenLots(){
	  var lots =  serverdata.lots_open;
	  $('.lots_open_profit').hide(); 
	  var profit_all = 0;	 
	  for (var i = 0; i < lots.length; i++) { 
		  var id  =  lots[i]['id'];
		  var profit = lots[i]['profit'];
		  var el = $('#lot_'+id).find('.profit');
		  
		
          if(profit)el.html(amountFormat(profit.toString()));
		  
		  profit_all += 1 * profit;
	      if(profit <= 0){
			 el.addClass('profit_down');
			 el.removeClass('profit_up'); 
		  }else{
			 el.addClass('profit_up');
			 el.removeClass('profit_down');  
		  }
		  
		  
		 $('.lots_open_profit').html(amountFormat(profit_all.toFixed(2)));
		 $('.lots_open_profit').show();  
	  
	  }
}
		 		

function  amountFormat(v){
		 var r  = '';
		 if(v < 0){
			var s =  v.split('-');
			r = '- R$ '+s[1]; 
		 }
		 if(v > 0){
			r = '+ R$ '+v; 	 
		 }
		 if(v == 0){
			r = ' R$ '+v; 	 
		 }
	return r; 
}
	
	

	
function   timeNow(){
	  return Math.floor(Date.now()/1000);
}
	



function _menu() {
    sc();
    
    // $(".slider_menu").fadeToggle();

    if ($(".slider_menu").css('display') == "none") {
        $(".slider_menu").fadeIn();
        // $(".slider_menu").show();
        //$(".bgwindow").show();
    } else {
        $(".slider_menu").fadeOut();
        // $(".slider_menu").hide();
        $(".bgwindow").hide();
    }
}



function chartBodyClick(){
	// $('.popup').hide();
	// $('.chat').hide(); 
	// $(".slider_menu").hide();
    // $('body').find('.iconbar_window').hide();

    $('.popup').fadeOut();
	$('.chat').fadeOut(); 
	$(".slider_menu").fadeOut();
    $('body').find('.iconbar_window').fadeOut();
	
}
 

function addDemo() {
    sc();
    $.ajax({
        url: '/traderoom/balance/add_demo',
        type: 'get',
        success: function(response) {}
    });
}


function getCurrencyList(obj, category, soundclick = 0) {
	if(soundclick == 1) sc();

    if(obj){
		$('.item').removeClass('selected');
        $(obj).addClass('selected');
     }

    $.ajax({
        url: '/traderoom/currency/' + category,
        type: 'get',
        success: function(response) {
            $(obj).parent().parent().find('.currency').html(response);
        }
    });
}


function getCurrencyListDef(category) {

    $.ajax({
        url: '/traderoom/currency/' + category,
        type: 'get',
        success: function(response) {
            $('.curreny_table').find('.currency').html(response);
        }
    });
}




var  window_id = 0;

function addTab(){
    $('.popup').fadeToggle();
	$('.popup').hide();
	window_id = 0;
    openblock('add_tab', '60px', '50%');
}
 



function setCurrency(id) {

	if(window_id == 0){
        w1.setCurrency(id); 
		saveWindow(1, id);
		saveTab(id);
    }

	if(window_id > 0){
		var classname = "w"+window_id;
		if(window[classname] != undefined){
         window[classname].setCurrency(id); 
		 saveWindow(window_id, id);
	    }
    }

    closeblock();
}




  

// type == 0;
function setWindowType(type) {
    //sc();
		  $('#w1').css('z-index','2'); 
	if(type == 0){
		
 
	 
	  
		$('#w1').animate({"width":"100%"}, 400);
	   $('#w2').css('left','0');	
	  // $('#w1').css('width','100%');
	   $('#w2').css('width','100%');
		 
		
	}
	
	if(type == 1){
		
 
		
	 
	   $('#w1').css('left','0');
	   $('#w2').css('left','50%');
       $('#w1').animate({"width":"50%"}, 400);
	  // $('#w1').css('width','50%');
	   $('#w2').css('width','50%'); 
	
	}
	
	
    $.ajax({
        url: '/traderoom/save/window/' + type,
        type: 'get',
        success: function(response) {
           // location.reload();
        }
    });
	
	closeblock();
}




var count_tabs = 0;

function tabs_list() {
    $.ajax({
        url: '/traderoom/tabs/list',
        type: 'get',
        success: function(response) {
            if (response) {

                //console.log(response.length);

                $('#tabs').html(response);
                tabs_width();
            }
        }
    });
}

tabs_list();




function saveTab(currency_id) {
    $.ajax({
        url: '/traderoom/tabs/add/' + currency_id,
        type: 'get',
        success: function(response) {
            tabs_list();
        }
    });
}

var lock_opentab = 0;

function delTab(currency_id) {
    sc();
    lock_opentab = 1;
    $.ajax({
        url: '/traderoom/tabs/del/' + currency_id,
        type: 'get',
        error: function() {
            lock_opentab = 0;
        },
        success: function(response) {
            tabs_list();
            lock_opentab = 0;
        }
    });
}


function openTab(currency_id) {
    if (lock_opentab == 1) return false;
	$('#page').hide();
    w1.setCurrency(currency_id);
    saveWindow(1, currency_id);
    sc();
}



function map(number, inMin, inMax, outMin, outMax) {
    return (number - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}


function tabs_width() {
    $('.add_tab').show();
    var all = $('.tabs .tab').length;

    if (all >= 6) $('.add_tab').hide();
    var s = $('.head_left').width();
    var r = $('.head_right').width();
    
	var w = $(window).width();
    
	$('.tabs .tab').eq(0).css('margin-left', '10px');

    if (w < 1200) return false;

    var t = w - (s + r) - 10;
    $('.tabs').css('width', t + 'px');

    // range map  1200px 1900px  =>  -80px  -5px
    var v = map(w, 1200, 2000, -80, -5);
    $('.tabs .tab').css('margin-left', v + 'px');
    $('.tabs .tab').eq(0).css('margin-left', '10px');
}




var months = new Array('Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro');
var months_ = new Array('Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez');

function getDateTime() {
    var now = new Date();
    var year = now.getFullYear();
    var day = now.getDate();
    var hour = now.getHours();
    var minute = now.getMinutes();
    var second = now.getSeconds();
    if (day.toString().length == 1) {
        day = '0' + day;
    }
    if (hour.toString().length == 1) {
        hour = '0' + hour;
    }
    if (minute.toString().length == 1) {
        minute = '0' + minute;
    }
    if (second.toString().length == 1) {
        second = '0' + second;
    }
	
	var n  = now.getMonth();
	var m = months[n];
	
	
    var dateTime = day + ' ' + m + ' ' + hour + ':' + minute + ':' + second;
    return dateTime;
}
setInterval(function() {
    currentTime = getDateTime();
    $('.time').html(currentTime);
}, 1000);




function playSound(src) {
    if (sound_status == 0) return false;
    var audio = new Audio(src);
    audio.play();
}


function sc() {
    // playSound("sounds/click.mp3");
}



function openblock(name, top, left) {
    sc();
    $("#" + name).css('top', top);
    $("#" + name).css('left', left);

    if (left == "50%") {
        var w = $("#" + name).width();
        w = w / 2;
        $("#" + name).css('margin-left', "-" + w + "px");
    } else {
        $("#" + name).css('margin-left', 0);
    }
    if ($("#" + name).css('display') == "none") {
        $("#" + name).show();
        //$(".bgwindow").show();
    } else {
        $("#" + name).hide();
        //$(".bgwindow").hide();
    }
}



function closeblock() {
    sc();
    $(".bgwindow").fadeOut();
    $(".popup").fadeOut();
}



function addFav(id) {
    sc();
    $.ajax({
        url: '/traderoom/currency/fav_add/' + id,
        type: 'get',
        success: function(response) {

            if (response == 'del') {
                $('#fav' + id).removeClass('active');
            }
            if (response == 'add') {
                $('#fav' + id).addClass('active');
            }
        }
    });
}


function saveWindow(num, currency_id) {
    $.ajax({
        url: '/traderoom/save/w' + num + '/' + currency_id,
        type: 'get',
        success: function(response) {}
    });
}




function redir(url) {
    document.location.href = url;
}


function selects() {
    $('.select2 select').bind('change', function() {
        var val = $(this).children(':selected').text();
        $(this).parent().find('.value').html(val);
    });
    var selected = $('.select2 option:selected');
    for (var j = 0; j < selected.length; j++) {
        if (selected[j]) {
            var val = $(selected[j]).text();
            $(selected[j]).parent().parent().find('.value').html(val);
        }
    }
}




 
function sound() {
    if (sound_status == 1) {
        $('.sound').addClass('off');
        sound_status = 0;
    } else {
        $('.sound').removeClass('off');
        sound_status = 1;
		sc();
    }
    savesound(sound_status);
}


function savesound(status) {
    $.ajax({
        url: '/traderoom/save/sound/' + status,
        type: 'get',
        success: function(response) {}
    });
}




function setCurrencyW2(id){
    var classname = "w2";
	if(window[classname] != undefined){
		 window[classname].setCurrency(id); 
		 saveWindow(2, id);
		 setWindowType(1);
	}
}

 



function isMobile() {
	var w  = $(window).width();
    if (w < 800  &&  w > 0) return true;
    return false;
}



function windowH() {
    if (window.innerHeight) {
        return window.innerHeight;
    } else {
        return document.body.clientHeight;
    }
}




function select_click(obj) {
    sc();
    if ($(obj).parent().find('.selects_list').css('display') == "block") {
        // $(obj).parent().find('.selects_list').hide();
        $(obj).parent().find('.selects_list').fadeOut();
    } else {
        // $(obj).parent().find('.selects_list').show();
        $(obj).parent().find('.selects_list').fadeIn();
    }
}




function FullScreen() {
	sc();
 var elem = document.body;
    if ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen)) {
        if (elem.requestFullScreen) {
            elem.requestFullScreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullScreen) {
            elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        }
    } else {
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}






	
// $(function(){
//     var prev_x = -1;
//     var prev_y = -1;
 
// 	$("#resize").mousedown(function(e){
//         prev_x = e.clientX;
//         prev_y = e.clientY;
//     });
    
//     $(document).mousemove(function(e){
//         if (prev_x == -1) return;
        
//         var boxY = $(".lots").position().top;
//         var boxH = $(".lots").height();
//         var dx = e.clientX - prev_x;
//         var dy = e.clientY - prev_y;
       
//         boxY += dy;
//         boxH -= dy;
     
		
// 		if(boxH > 150)  boxH = 150;
// 		if(boxH < 60)  boxH = 60;
		
// 	     //  ru/account/save/lot_height/300
             
//         $(".lots").css({
//             "height":(boxH)+"px",
//         });
		 
	 
//         var h_lots =  $('.lots').height();
//         var h  = windowH()-100-h_lots;
 
//         $('.main').css('height', h+'px');	
//         $('.chart_window').css('height', h+'px');
// 		$('.lots_table .table_list').css('height', boxH-65+'px');
// 	    addlotResize(h);
		
//         prev_x = e.clientX;
//         prev_y = e.clientY;
//     });

//     $(document).mouseup(function(){ 
//         prev_x = -1;
//         prev_y = -1;
//     });
// });	
	
	
function addlotResize(h){
   if(h < 600){
	 $('.right .name').hide();
	 $('.right .help').hide();  
   }else{
	 $('.right .name').show();
	  $('.right .help').show();  
   }
}	
	
function openChat(){
  sc();
  $(".slider_menu").hide();
  if($('.chat').css('display') == 'none'){
	  $('.chat').show();
  }else{
	  $('.chat').hide(); 
  }
}


function openChats(){
    sc();
    $(".slider_menu").hide();
    if($('.chats').css('display') == 'none'){
        $('.chats').show();
    }else{
        $('.chats').hide(); 
    }
  }



function datapost(element){
	var data = '';
	var form = $(element).find('select');
    for(var i=0;i<form.length;i++){
		data  += form[i]['name'] +'='+form[i]['value']+ '&';
    }
	var form = $(element).find('input');
    for(var i=0;i<form.length;i++){
		 if($(form[i]).attr('type') == 'checkbox'){
		   if($(form[i]).prop('checked')){
              data  += form[i]['name'] +'='+form[i]['value']+ '&';
		   }else{
              data  += form[i]['name'] +'=&'; 
		   }
		 }else{
		   data  += form[i]['name'] +'='+form[i]['value']+ '&';
		 }
    }
  return data;
}


function mess(text){
  $('.mess').html(text);
  $('.mess').css('display', 'table');	
  $('.mess').removeClass('ok');
}

function mess2(text){
  $('.mess2').html(text);
  $('.mess2').css('display', 'table');	
  $('.mess2').removeClass('ok');
}

function messOk(text){
  $('.mess').html(text);
  $('.mess').css('display', 'table');		
  $('.mess').addClass('ok');
}

function mess2Ok(text){
  $('.mess2').html(text);
  $('.mess2').css('display', 'table');		
  $('.mess2').addClass('ok');
}


function _switch(){
	$(".switch").each(function(){
		var st = $(this).find('input').val();
		if(st == 1){  
		  $(this).css('background-color', '#318ED2');
		  $(this).find('.c').css('margin-left', '24px');
		}
    });
    $(".switch").on( "click", function() {
		var st = $(this).find('input').val();
		if(st == 1){  
			$(this).find('input').val('0');
		    $(this).css('background-color', '#3E4664');
		    $(this).find('.c').css('margin-left', '4px');
		}else{
			$(this).find('input').val('1');
			$(this).css('background-color', '#318ED2');
		    $(this).find('.c').css('margin-left', '24px');
		}
      sc();
   });
}




$(window).resize(function() {
    tabs_width();
	if(isMobile()) redir('/mob');
});


$(document).ready(function() {

    // if (window.innerWidth <= 768) {
    //     // É um dispositivo móvel (largura menor ou igual a 768 pixels)
    //     console.log("Usuário está usando um dispositivo móvel.");
    //     redir('/mob');
    // } else {
    //     // É um desktop
    //     console.log("Usuário está usando um desktop.");
    // }







	if(isMobile()) redir('/mob');
	//createSocket()
    _server();	
	 _switch();
	
    _ranking();
	
	

 
    
    document.oncontextmenu = function() {return false;};
	
	
	// tabs right click event
    $(document).mousedown(function(e){ 
      if( e.button == 2 ) { 
       var et = $(e.target);
       var w2id =  et.find('.right_click').val();
	  // if(!w2id) w2id =  et.parent().parent().find('.right_click').val(); 
	   if(w2id > 0) setCurrencyW2(w2id);
      return false; 
      } 
      return true; 
    }); 
	
	
 
    $('.bodyclick').click(function(event) {
        event.stopPropagation();
        
    });

    $('body').click(function() {
        
        $(".bodyclick_hide").fadeOut();
        $(".selects_list").fadeOut();
		$('.chat').fadeOut();

    });


    $('.selects_label').click(function(event) {
        event.stopPropagation();
    });

    tabs_list();


    selects();

    getCurrencyListDef(7);

    $('input').attr('autocomplete','off');	
});


var copyBusca_prev = '';
function copySearchUser(page, val){
	console.log(val);
	// console.log(payout_prev);

	$.ajax({
		url: '/traderoom/copy/filtro',
		type: 'post',
		data: {'page':page, 'q': val},
		error:function(){
		},
		success: function(data){
			// if(copyBusca_prev != data){
            //     copyBusca_prev = data;
                $('#listCopyUsers').html(data);
            // }
		}
	});	 

}